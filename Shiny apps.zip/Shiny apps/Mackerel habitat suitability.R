library(shiny)
library(leaflet)
library(raster)

# Define UI
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body {
        background-color: #111111; /* Dark background color */
        color: #FFFFFF; /* White text color */
      }
      .description-box {
        max-height: 300px; /* Adjust the maximum height of the text box */
        overflow-y: auto; /* Enable vertical scrollbar if needed */
        background-color: #FFFFFF; /* White background color */
        color: #000000; /* Black text color */
      }
      .js-irs-0 .irs-single, .js-irs-0 .irs-from, .js-irs-0 .irs-to, .js-irs-0 .irs-grid-text {
        color: #000000 !important; /* Set color to black */
      }
      .irs-from {
        color: #000000 !important; /* Set color to black for slider title */
      }
    "))
  ),
  titlePanel("Climate Change Modelling - Atlantic Mackerel Habitat Suitability Maps"),
  sidebarLayout(
    sidebarPanel(
      actionButton("play", "Play"),
      sliderInput("year", "Select Year:",
                  min = 2020, max = 2100, value = 2020, step = 10),
      div(textOutput("description"), class = "description-box")
    ),
    mainPanel(
      leafletOutput("map"),
      verbatimTextOutput("clicked_info")
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  
  # Description text
  output$description <- renderText({
    "INTRODUCTION:
    Where will mackerel migrate to after climate change?
    
    This application aims to address how climate-driven migrations of pelagic fish in European seas create an environment. Warming waters push species like Atlantic mackerel to navigate this intricate challenge. Innovative solutions and renewed international commitment are essential for securing a sustainable future for both the marine environment and dependent communities.
    
    This application aims to address this by displaying habitat suitability maps for Atlantic mackerel from 2020 to 2100.
    
    A blue to yellow colour scale:
    - blue = low suitability
    - red = high suitability
    (all suitability is between 0 and 1)
    A year can be selected using the slider below.
    
    Pushing the green play button will allow you to progress automatically through the years from 2020 to 2100.
    You can also click on the map to see the habiatat suitability."
  })
  
  observeEvent(input$play, {
    req(input$play)
    isolate({
      for (i in seq(2020, 2100, by = 10)) {
        updateSliderInput(session, "year", value = i)
        Sys.sleep(0.5)  # Pause for 0.5 second between each year
        session$allowReconnect(FALSE)
      }
    })
  })
  
  output$map <- renderLeaflet({
    # Load the selected map
    filename <- paste0("C:/Users/rutendo.musimwa/OneDrive - VLIZ/MDA Cliamate cahange/Climate Change Modelling/Output/Mackerel/Temperature/Non Spawning/SSP585/SSP585_", input$year, ".tif")
    map <- raster::raster(filename)
    
    # Convert raster to rasterBrick if it's a multilayered raster
    if (nlayers(map) > 1) {
      map <- brick(map)
    }
    
    # Define the extent of your study area
    extent <- extent(c(xmin = -20, xmax = 40, ymin = 30, ymax = 65))
    
    # Crop the map to your study area
    cropped_map <- crop(map, extent)
    
    # Plot the map
    leaflet() %>%
      addProviderTiles("CartoDB.DarkMatter") %>%
      addRasterImage(cropped_map, opacity = 0.7) %>%
      addLegend(pal = colorNumeric("viridis", values(cropped_map)),
                values = values(cropped_map),
                title = "Habitat Suitability",
                opacity = 0.7) %>%
      setView(lng = (extent@xmin + extent@xmax) / 2, lat = (extent@ymin + extent@ymax) / 2, zoom = 3)
  })
  
  # Event handler for map click
  output$clicked_info <- renderPrint({
    req(input$map_click)
    # Get the clicked coordinates
    click_lat <- input$map_click$lat
    click_lng <- input$map_click$lng
    
    # Load the selected map
    filename <- paste0("C:/Users/rutendo.musimwa/OneDrive - VLIZ/MDA Cliamate cahange/Climate Change Modelling/Output/Mackerel/Temperature/Non Spawning/SSP585/SSP585_", input$year, ".tif")
    map <- raster::raster(filename)
    
    # Check if clicked coordinates fall within the extent of the raster data
    if (click_lng >= xmin(map) & click_lng <= xmax(map) & click_lat >= ymin(map) & click_lat <= ymax(map)) {
      # Convert the clicked coordinates to raster coordinates
      click_coords <- c(click_lng, click_lat)
      
      # Extract the pixel value at the clicked coordinates
      pixel_value <- extract(map, list(click_coords))
      
      # Check if the pixel value is NA
      if (is.na(pixel_value)) {
        return("Pixel value not available for clicked location.")
      } else {
        # Output the pixel value
        return(paste("Habitat Suitability Index:", pixel_value))
      }
    } else {
      return("Clicked location is not within the study area.")
    }
  })
}

# Run the application
shinyApp(ui = ui, server = server)
