# Install or update required packages
if (!requireNamespace("install.packages", quietly = TRUE)) {
  install.packages("install.packages")
}
install.packages(c("raster", "sf", "ggplot2"))

# Load required packages
library(raster)
library(sf)
library(ggplot2)

# Function to perform normality test on a TIF file
perform_normality_test <- function(tif_file) {
  # Read the data from the TIF file
  raster_data <- raster(tif_file)
  data_values <- getValues(raster_data)
  
  # Check if the sample size is within an acceptable range
  if (length(data_values) < 3 || length(data_values) > 5000) {
    cat("Sample size is not within the acceptable range for normality test for file:", tif_file, "\n")
    cat("Skipping normality test for this file.\n")
    
    # Plot a histogram for visual inspection using ggplot2
    hist_plot <- ggplot(data.frame(values = data_values), aes(x = values)) +
      geom_histogram(fill = "skyblue", color = "black", bins = 30) +
      ggtitle(paste("Histogram for", tif_file)) +
      xlab("Values") +
      ylab("Frequency") +
      theme_minimal()
    
    # Print the histogram within R
    print(hist_plot)
    
    return()
  }
  
  # Perform Shapiro-Wilk test for normality
  shapiro_test_result <- shapiro.test(data_values)
  
  # Print the results
  cat("\nFile:", tif_file, "\n")
  cat("Shapiro-Wilk Test Statistic:", shapiro_test_result$statistic, "\n")
  cat("P-value:", shapiro_test_result$p.value, "\n")
  
  # Check the null hypothesis
  alpha <- 0.05
  if (shapiro_test_result$p.value < alpha) {
    cat("The null hypothesis (data is normally distributed) is rejected.\n")
  } else {
    cat("The null hypothesis (data is normally distributed) cannot be rejected.\n")
  }
  
  # Plot a histogram for visual inspection using ggplot2
  hist_plot <- ggplot(data.frame(values = data_values), aes(x = values)) +
    geom_histogram(fill = "skyblue", color = "black", bins = 30) +
    ggtitle(paste("Histogram for", tif_file)) +
    xlab("Values") +
    ylab("Frequency") +
    theme_minimal()
  
  # Print the histogram within R
  print(hist_plot)
}

# Function to check normality for all TIF files in a folder
check_normality <- function(folder_path) {
  # Get a list of all TIF files in the folder
  tif_files <- list.files(folder_path, pattern = "\\.tif$", full.names = TRUE)
  
  if (length(tif_files) == 0) {
    cat("No TIF files found in the specified folder.\n")
    return()
  }
  
  cat("Performing normality tests and plotting histograms for each TIF file:\n")
  for (tif_file in tif_files) {
    perform_normality_test(tif_file)
  }
}

# Load the raster package
if (!requireNamespace("raster", quietly = TRUE)) {
  install.packages("raster")
}
library(raster)

# Specify the path to the TIFF file
tif_path <- "C:/Users/rutendo.musimwa/OneDrive - VLIZ/BAR ecological modelling/Scripts/Mackerel/Input-output_files Mackerel/Climate change/BioOracle New/Spawning vs Non Spawning/Worst case/Non Spawning/SSP585_2090.tif"

# Read the raster data
raster_data <- raster(tif_path)

# Get the latitude values
latitudes <- yFromCell(raster_data, 1:ncell(raster_data))

# Find the latitude where the pixel value is closest to 0.75
closest_lat <- latitudes[which.min(abs(values(raster_data) - 0.75))]

# Print the result
cat("Latitude where the pixel value is closest to 0.75:", closest_lat, "\n")

# Specify the folder path containing the GeoTIFF files
folder_path <- "C:/Users/rutendo.musimwa/OneDrive - VLIZ/BAR ecological modelling/Scripts/Mackerel/Input-output_files Mackerel/Climate change/BioOracle New/Different climate change scenarios/SSP126/HSM maps per variable/Non Spawning"

# Call the function to check normality
check_normality(folder_path)
