library(shiny)
library(tidyverse)
library(raster)
library(maps)
library(colourpicker)
library(ncdf4)
library(lubridate)
library(gridExtra)
library(leaflet)

setwd("C:/Users/ward.standaert/OneDrive - VLIZ/BAR ecological modelling/MDA storage/Mechanistic approach")
bpns <- terra::vect("DATA/1.DOWNLOAD/bpns_shp/eez.shp")
pal <- colorNumeric(c("#30123b", "#3e9cfe","#a4fc3c","#4af880","#e3db38","#ef5811","#7a0403"), 
                    c(0,1.001), na.color = "transparent")


# implement the app's user interface 
ui <- fluidPage(
    fluidRow(
      column(2, "Jan", uiOutput("f1")), column(2, "Feb", uiOutput("f2")), column(2, "Mar", uiOutput("f3")),
      column(2, "Apr", uiOutput("f4")), column(2, "May", uiOutput("f5")), column(2, "Jun", uiOutput("f6")) 
      ),
    fluidRow(
      column(2, "Jul", uiOutput("f7")), column(2, "Aug", uiOutput("f8")), column(2, "Sep", uiOutput("f9")), 
      column(2, "Oct", uiOutput("f10")), column(2, "Nov", uiOutput("f11")), column(2, "Dec", uiOutput("f12"))
      ),
    absolutePanel(bottom = 10, right = 10,
                  # to select species
                  selectInput("species", "Species:", choices = list("Atlantic herring" = "Herring", 
                                                                  "Atlantic mackerel" = "Mackerel", 
                                                                  "European seabass" = "Seabass")),
                  
                  # to select scenario
                  selectInput("scenario", "Scenario:", choices = list("Most likely scenario" = "most_likely_scenario", 
                                                                      "Worst scenario" = "worst_scenario", 
                                                                      "Best scenario" = "best_scenario")),
                  
                  # to select lifestage
                  selectInput("lifestage", "Life stage:", choices = list("Non-spawning" = "non_spawning", 
                                                                         "spawning" = "spawning")),
    )
)

server <- function(input, output) {
  
  output$f1 <- renderUI( { 
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_1.tif")
    raster(path)

    f1 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    
    f1 })
  
  output$f2 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_2.tif")
    raster(path)
    
    f2 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
     f2 })
  
  output$f3 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_3.tif")
    raster(path)
    
    f3 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f3 })
  
  output$f4 <- renderUI( { 
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_4.tif")
    raster(path)
    
    f4 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f4 })
  
  output$f5 <- renderUI( { 
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_5.tif")
    raster(path)
    
    f5 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f5 })
  
  output$f6 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_6.tif")
    raster(path)
    
    f6 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f6 })
  
  output$f7 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_7.tif")
    raster(path)
    
    f7 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f7 })
  
  output$f8 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_8.tif")
    raster(path)
    
    f8 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f8 })
  
  output$f9 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_9.tif")
    raster(path)
    
    f9 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
  f9 })
  
  output$f10 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_10.tif")
    raster(path)
    
    f10 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f10 })
  
  output$f11 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_11.tif")
    raster(path)
    
    f11 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f11 })
  
  output$f12 <- renderUI( {
    
    path <- paste0("DATA/3.OUTPUT/HSI_MAPS_COMBINED/",input$species,"/", input$lifestage, "_", input$scenario, "_12.tif")
    raster(path)
    
    f12 <- leaflet(bpns) %>% 
      setView(lng = 2.75, lat = 51.5, zoom = 08) %>%
      addTiles() %>%
      addRasterImage(raster(path), colors = pal) %>%
      addLegend(pal = pal,
                values = c(0,1),
                title = "SI") %>%
      addPolygons(fillColor = "transparent",
                  color = "black",
                  weight = 1)
    f12 })
}

#run/call the shiny app
shinyApp(ui, server)


