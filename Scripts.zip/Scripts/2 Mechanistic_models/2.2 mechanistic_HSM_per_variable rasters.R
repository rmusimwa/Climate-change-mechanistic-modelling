# Load required library
library(raster)

# New base directory
base_dir <- "C:\\Users\\rutendo.musimwa\\OneDrive - VLIZ\\MDA Climate change\\Climate Change Modelling\\Output"

# Files to be plotted
input_pairs <- list(
  c(
    paste0(base_dir, "/Herring/Temperature/Non Spawning/baseline/baseline.tif"),
    paste0(base_dir, "/Herring/Temperature/Non Spawning/SSP119/SSP119_2090.tif")
  ),
  c(
    paste0(base_dir, "/Mackerel/Temperature/Non Spawning/baseline/mackerel.tif"),
    paste0(base_dir, "/Mackerel/Temperature/Non Spawning/SSP119/SSP119_2090.tif")
  ),
  c(
    paste0(base_dir, "/Seabass/Temperature/Non Spawning/baseline/baseline.tif"),
    paste0(base_dir, "/Seabass/Temperature/Non Spawning/SSP119/SSP119_2090.tif")
  )
)

# Create a function to plot the difference between aligned rasters
plot_difference <- function(pair) {
  baseline <- raster(pair[1])
  ssp119_2090 <- raster(pair[2])
  
  # Match extent, resolution, and CRS of rasters
  ssp119_2090_matched <- resample(ssp119_2090, baseline, method = "bilinear")
  
  difference <- ssp119_2090_matched - baseline
  
  plot(difference, main = "", col = "RdBu", legend = FALSE)
}

# Plot the difference for each pair and save as an image
for (pair in input_pairs) {
  species <- gsub(".tif", "", basename(pair[1]))
  species <- gsub("_", " ", species)
  png(file = paste0(species, "_difference.png"), width = 800, height = 600)
  plot_difference(pair)
  dev.off()  # Close the PNG device
}

